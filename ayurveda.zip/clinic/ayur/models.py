from django.db import models

class Appointment(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    date = models.DateField()
    message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.date}"

    class Meta:
        ordering = ['-date']  # latest appointments first

