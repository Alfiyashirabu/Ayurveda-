from django.contrib import admin
from .models import Appointment

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'date', 'created_at')
    list_filter = ('date', 'created_at')
    search_fields = ('name', 'email')
    date_hierarchy = 'date'
    ordering = ('-date',)

