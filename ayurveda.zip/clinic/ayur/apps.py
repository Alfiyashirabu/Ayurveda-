from django.apps import AppConfig


class AyurConfig(AppConfig):
    name = 'ayur'
