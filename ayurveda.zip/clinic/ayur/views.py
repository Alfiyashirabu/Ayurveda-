from django.shortcuts import render, redirect
from django.contrib import messages

from .models import Appointment

def home(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        date = request.POST.get('date')
        message = request.POST.get('message')

        Appointment.objects.create(
            name=name,
            email=email,
            date=date,
            message=message
        )



        return redirect('home')

    return render(request, 'home.html')
